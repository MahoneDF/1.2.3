//
// Created by DavoudAbadi on 12/8/2023.
//

#ifndef COUNTER_CONTROLLER_H
#define COUNTER_CONTROLLER_H


#include "../model/User.h"
#include "../view/Massage.h"
#include "../model/Game.h"

class Controller {
private:
    static Game* game;
public:
    static void setGame(Game* game);

    static Massage addUser(const std::string& username, const std::string& team, const int& minutes, const int& seconds, const int& miliseconds, Game* game1);
    static Massage tap(std::string& attackerName, std::string& attackedName, std::string& gunName, Game* game1);



    static Massage getMoney(const std::string &username, const int &minutes, const int &seconds, const int &miliseconds, Game* game1);

    static Massage getHealth(const std::string &username, const int &minutes, const int &seconds, const int &miliseconds, Game* game1);

    static Massage buy(std::string &username, std::string &gunName, const int &minutes, const int &seconds, const int &miliseconds, Game* game1);



    static bool checkTime(const int &minutes1, const int &seconds1, const int &miliseconds1, const int &minutes2,
              const int &seconds2,
              const int &miliseconds2);

    static Massage newRound(Game* game1);


    static User &getUserByName(const std::string &username);
};



#endif //COUNTER_CONTROLLER_H

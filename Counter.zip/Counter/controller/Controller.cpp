//
// Created by DavoudAbadi on 12/8/2023.
//

#include "Controller.h"
#include <cmath>
#include <iostream>


Game* Controller::game = nullptr;

Massage Controller::addUser(const std::string& username, const std::string& team, const int& minutes, const int& seconds, const int& miliseconds, Game* game1) {
    game = game1;
    if(!game->getUserByName(username).getUsername().empty()){
        return Massage::USERNAME_EXISTS;
    } else if((team == "Terrorist" && game->getNumberOfTerrorist() >= 10) || (team == "Counter-Terrorist" && game->getNumberOfCounterTerrorist() >= 10)){
        return Massage::TEAM_IS_FULL;
    }else{
        User user(username, team);
        if(checkTime(minutes, seconds, miliseconds, 0, 3, 0)){
            user.setHealth(0);
        }
        game->addUser(user);
//        if(checkTime(minutes, seconds, miliseconds, 0, 3, 0)){
//            for(auto & user1 : game->getAllUsers()){
//                if(user1.getUsername() == username) {
//                         user1.setHealth(0);
//                }
//            }
//        }

        return Massage::SUCCESS_ADD;
    }
}


Massage Controller::getMoney(const std::string& username, const int& minutes, const int& seconds, const int& miliseconds, Game* game1){
    game = game1;
    if(game->getUserByName(username).getUsername().empty()){
        return Massage::INVALID_USERNAME;
    }else{
        return Massage::GET_MONEY;
    }
}

Massage Controller::getHealth(const std::string& username, const int& minutes, const int& seconds, const int& miliseconds, Game* game1){
    game = game1;
    if(game->getUserByName(username).getUsername().empty()){
        return Massage::INVALID_USERNAME;
    }else{
        return Massage::GET_HEALTH;
    }
}

Massage Controller::tap(std::string& attackerName, std::string& attackedName, std::string& gunName, Game* game1) {
    game = game1;
    User attacker = game->getUserByName(attackerName);
    User attacked = game->getUserByName(attackedName);
    if(attacker.getUsername().empty() || attacked.getUsername().empty()){
        return Massage::INVALID_USERNAME;
    }else if(attacker.getHealth() == 0){
        return Massage::DEAD_ATTACKER;
    }else if(attacked.getHealth() == 0){
        return Massage::DEAD_ATTACKED;
    }else if((gunName == "heavy" && !attacker.haveHeavyGun()) || (gunName == "pistol" && !attacker.haveHandgun())){
        return Massage::GUN_DOES_NOT_EXISTS;
    } else if ((attacker.isTerrorist() && attacked.isTerrorist()) || (!attacker.isTerrorist() && !attacked.isTerrorist())){
        return Massage::FRIENDLY_FIRE;
    } else{
        int damage;
        int price;
        if(gunName == "heavy"){
            ////todo:...............
            damage = attacker.getHeavyGun().getProperties().damage;
            price = attacker.getHeavyGun().getProperties().price;

        }else if(gunName == "pistol"){
            damage = attacker.getHandgun().getProperties().damage;
            price = attacker.getHandgun().getProperties().price;
        }else{
            damage = 43;
            price = 500;
        }
        bool isKilled = false;
        for(auto & user : game->getAllUsers()){
            if(user.getUsername() == attackedName){
                user.setHealth(std::max(user.getHealth() - damage, 0));
                if(user.getHealth() == 0){
                    isKilled = true;
                    user.incNumberOfDeath();
                }
            }
        }
        if(isKilled){
            for(auto & user : game->getAllUsers()){
                if(user.getUsername() == attackerName){
                    user.incNumberOfKill();
                    user.setMoney(std::min(game->getUserByName(attackerName).getMoney() + price, 10000));
                }
            }
        }

        return Massage::NICE_SHOT;
    }
}

Massage Controller::buy(std::string& username, std::string& gunName, const int& minutes, const int& seconds, const int& miliseconds, Game* game1) {
    game = game1;
    User player = game->getUserByName(username);
    if(player.getUsername().empty()){
        return Massage::INVALID_USERNAME;
    } else if(player.getHealth() == 0){
        return Massage::USER_IS_DEAD;
    } else if (checkTime(minutes, seconds, miliseconds, 0, 45, 0)){
        return Massage::OUT_OF_TIME;
    } else if(getHandgunPropertyByName(gunName) != nullptr){
        if(player.isTerrorist() && !getHandgunPropertyByName(gunName)->isForTerrorist){
            return Massage::INVALID_CATEGORY_GUN;
        } else if(!player.isTerrorist() && !getHandgunPropertyByName(gunName)->isForCounterTerrorist){
            return Massage::INVALID_CATEGORY_GUN;
        }else if(player.haveHandgun()){
            return Massage::HANDGUN_EXISTS;
        }
        else if(player.getMoney() < getHandgunPropertyByName(gunName)->cost){
            return Massage::NO_ENOUGH_MONEY;
        }else{
            for(auto & user : game->getAllUsers()){
                if(user.getUsername() == username){
                    Handgun handgun(*getHandgunPropertyByName(gunName));
                    user.setHandgun(handgun);
                    user.setMoney(user.getMoney() - handgun.getProperties().cost);
                    return Massage::SUCCESS_BUY;
                }
            }

        }
    }else if(getHeavyGunPropertyByName(gunName) != nullptr){
        if(player.isTerrorist() && !getHeavyGunPropertyByName(gunName)->isForTerrorist){
            return Massage::INVALID_CATEGORY_GUN;
        } else if(!player.isTerrorist() && !getHeavyGunPropertyByName(gunName)->isForCounterTerrorist){
            return Massage::INVALID_CATEGORY_GUN;
        }else if(player.haveHeavyGun()){
            return Massage::HEAVY_GUN_EXISTS;
        }else if(player.getMoney() < getHeavyGunPropertyByName(gunName)->cost){
            return Massage::NO_ENOUGH_MONEY;
        }else{
            for(auto & user : game->getAllUsers()){
                if(user.getUsername() == username){
                    HeavyGun heavyGun(*getHeavyGunPropertyByName(gunName));
                    user.setHeavyGun(heavyGun);
                    user.setMoney(user.getMoney() - heavyGun.getProperties().cost);
                    return Massage::SUCCESS_BUY;
                }
            }

        }
    }
}

Massage Controller::newRound(Game* game1){
    game = game1;
    bool isCounterTerroristWin = true;
    int counterTerroristPrice = 2700;
    int terroristPrice = 2400;
    int numberOfTerroristAlive = 0;
    int numberOfCounterTerroristAlive = 0;
    for(auto& user : game->getAllUsers()){
        if(user.getHealth() > 0){
            if(user.isTerrorist()){
                numberOfTerroristAlive++;
            } else{
                numberOfCounterTerroristAlive++;
            }
        } else{
            user.setHaveHeavyGun(false);
            user.setHaveHandgun(false);
        }
    }
    if(numberOfCounterTerroristAlive == 0 && numberOfTerroristAlive > 0){
        isCounterTerroristWin = false;
        counterTerroristPrice = 2400;
        terroristPrice = 2700;
    }
    for(auto& user : game->getAllUsers()){
        user.setHealth(100);
        if(user.isTerrorist()){
            user.setMoney(std::min(user.getMoney() + terroristPrice,  10000));
        } else{
            user.setMoney(std::min(user.getMoney() + counterTerroristPrice,  10000));
        }

    }
    game->decRound();
    if(isCounterTerroristWin){
        return Massage::COUNTER_TERRORIST_WIN;
    }
    return Massage::TERRORIST_WIN;


}

void Controller::setGame(Game* game1) {
    game = game1;
}


bool Controller::checkTime(const int& minutes1, const int& seconds1, const int& miliseconds1, const int& minutes2, const int& seconds2, const int& miliseconds2) {
    if(minutes1 > minutes2){
        return true;
    }
    if (minutes1 == minutes2 && seconds1 > seconds2){
        return true;
    }
    if (minutes1 == minutes2 && seconds1 == seconds2 && miliseconds1 >= miliseconds2){
        return true;
    }
    return false;
}


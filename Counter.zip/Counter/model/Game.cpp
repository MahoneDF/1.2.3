//
// Created by DavoudAbadi on 11/28/2023.
//

#include "Game.h"
#include "vector"

void Game::addUser(User &user) {
    allUsers.push_back(user);
}

User Game::getUserByName(const std::string& username) {
    for(const auto & allUser : allUsers){
        if(allUser.getUsername() == username){
            return allUser;
        }
    }
    return User("", "Terrorist");
}

Game::Game(int &round1) {
    round = round1;
    passedRound = 0;
}

int Game::getNumberOfTerrorist() {
    int t = 0;
    for(const auto & user : allUsers){
        if(user.isTerrorist()){
            t++;
        }
    }
    return t;
}

int Game::getNumberOfCounterTerrorist() {
    int t = 0;
    for(const auto & user : allUsers){
        if(!user.isTerrorist()){
            t++;
        }
    }
    return t;
}
void Game::incPassedRound(){
    passedRound++;
}
void Game::decRound() {
    round--;
}

int Game::getRound() const {
    return round;
}

std::vector<User> &Game::getAllUsers() {
    return allUsers;
}

int Game::getPassedRound() const {
    return passedRound;
}

int Game::getNumberOfCommands() const {
    return numberOfCommands;
}

void Game::setNumberOfCommands(int numberOfCommands) {
    Game::numberOfCommands = numberOfCommands;
}

void Game::decNumberOfCommands() {
    numberOfCommands--;
}

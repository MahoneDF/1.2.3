//
// Created by DavoudAbadi on 11/27/2023.
//

#include <iostream>
#include "User.h"



int User::getHealth(){
    return health;
}

User::User(const std::string& _username, const std::string& _team): handgun(HandgunProperties()), heavyGun(HeavyGunProperties()){
    username = _username;
    if(_team == "Terrorist"){
        is_terrorist = true;
    } else if (_team == "Counter-Terrorist"){
        is_terrorist = false;
    }
    have_handgun = false;
    have_heavyGun = false;
    health = 100;
    money = 1000;
    numberOfDeath = 0;
    numberOfKill = 0;
}

HeavyGun User::getHeavyGun() {
    return heavyGun;
}

Handgun User::getHandgun() {
    return handgun;
}

const std::string &User::getUsername() const {
    return username;
}

int User::getMoney() const {
    return money;
}

bool User::isTerrorist() const {
    return is_terrorist;
}

bool User::haveHeavyGun() const {
    return have_heavyGun;
}

bool User::haveHandgun() const {
    return have_handgun;
}

void User::setHeavyGun(const HeavyGun &heavyGun) {
    User::heavyGun = heavyGun;
    have_heavyGun = true;
}

void User::setHandgun(const Handgun &handgun) {
    User::handgun = handgun;
    have_handgun = true;
}

void User::setHealth(int health) {
    User::health = health;
}

void User::setMoney(int money) {
    User::money = money;
}

void User::setHaveHeavyGun(bool haveHeavyGun) {
    have_heavyGun = haveHeavyGun;
}

void User::setHaveHandgun(bool haveHandgun) {
    have_handgun = haveHandgun;
}

void User::incNumberOfKill(){
    numberOfKill++;
}

void User::incNumberOfDeath(){
    numberOfDeath++;
}

int User::getNumberOfKill() const {
    return numberOfKill;
}

int User::getNumberOfDeath() const {
    return numberOfDeath;
}



//
// Created by DavoudAbadi on 12/1/2023.
//

#ifndef COUNTER_HANDGUN_H
#define COUNTER_HANDGUN_H


#include "HandgunType.h"
#include <regex>





class Handgun{
private:
    HandgunProperties properties;
public:
    Handgun(const HandgunProperties& properties1);

    const HandgunProperties &getProperties() const;


};


#endif //COUNTER_HANDGUN_H

//
// Created by DavoudAbadi on 12/8/2023.
//

#include "HandgunType.h"


HandgunProperties* getHandgunPropertyByName(const std::string &name) {
    for (int i = 0; i < 4; i++) {
        if (handgunPropertiesList[i].name == name) {
            return const_cast<HandgunProperties *>(&(handgunPropertiesList[i]));
        }
    }
    return nullptr;
}


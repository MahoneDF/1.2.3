//
// Created by DavoudAbadi on 11/27/2023.
//

#ifndef COUNTER_USER_H
#define COUNTER_USER_H


#include "HeavyGun.h"
#include "Handgun.h"

class User {
public:
    User(const std::string& _username, const std::string& _team);
    HeavyGun getHeavyGun();
    Handgun getHandgun();
    int getHealth();
    const std::string& getUsername() const;
    bool haveHeavyGun() const;
    bool haveHandgun() const;
    int getMoney() const;
    bool isTerrorist() const;


    void setHaveHeavyGun(bool haveHeavyGun);

    void setHaveHandgun(bool haveHandgun);

    void setMoney(int money);

    void setHeavyGun(const HeavyGun &heavyGun);

    void setHandgun(const Handgun &handgun);

    void setHealth(int health);
    void incNumberOfKill();

    void incNumberOfDeath();

    int getNumberOfKill() const;

    int getNumberOfDeath() const;

private:
    std::string username;
    bool is_terrorist;
    HeavyGun heavyGun;
    Handgun handgun;
    int health;
    int money;
    bool have_heavyGun;
    bool have_handgun;
    int numberOfKill;
    int numberOfDeath;
};


#endif //COUNTER_USER_H

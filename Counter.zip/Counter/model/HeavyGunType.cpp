//
// Created by DavoudAbadi on 12/9/2023.
//

#include "HeavyGunType.h"

HeavyGunProperties* getHeavyGunPropertyByName(const std::string &name) {
    for (int i = 0; i < 4; i++) {
        if (heavyGunPropertiesList[i].name == name) {
            return const_cast<HeavyGunProperties *>(&heavyGunPropertiesList[i]);
        }
    }
    return nullptr;
}
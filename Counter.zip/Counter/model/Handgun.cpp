//
// Created by DavoudAbadi on 12/1/2023.
//

#include "Handgun.h"
#include "HandgunType.h"




Handgun::Handgun(const HandgunProperties& properties1) {
    properties = properties1;
}

const HandgunProperties &Handgun::getProperties() const {
    return properties;
}

//
// Created by DavoudAbadi on 12/8/2023.
//

#ifndef COUNTER_HANDGUNTYPE_H
#define COUNTER_HANDGUNTYPE_H


#include <string>
#include <regex>



enum class HandgunType{
    REVOLVER,
    GLOCK_18,
    DESERT_EAGLE,
    UPS_S
};

struct HandgunProperties{
    std::string name;
    int cost;
    int damage;
    int price;
    bool isForTerrorist;
    bool isForCounterTerrorist;
    HandgunType type;
};

HandgunProperties* getHandgunPropertyByName(const std::string &name);

const HandgunProperties handgunPropertiesList[4] = {
        {"Revolver", 600, 51, 150, true, false,  HandgunType::REVOLVER},
        {"Glock-18", 300, 11, 200, true, false,      HandgunType::GLOCK_18},
        {"Desert-Eagle", 600, 53, 175, false, true, HandgunType::DESERT_EAGLE},
        {"UPS-S", 300, 13, 225, false, true,        HandgunType::UPS_S}
};





#endif //COUNTER_HANDGUNTYPE_H

//
// Created by DavoudAbadi on 12/1/2023.
//

#include "HeavyGun.h"

HeavyGun::HeavyGun(const HeavyGunProperties& properties1) {
    properties = properties1;
}

const HeavyGunProperties &HeavyGun::getProperties() const {
    return properties;
}

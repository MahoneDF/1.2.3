//
// Created by DavoudAbadi on 12/9/2023.
//

#ifndef COUNTER_HEAVYGUNTYPE_H
#define COUNTER_HEAVYGUNTYPE_H



#include <string>
#include <regex>

enum class HeavyGunType{
    AK,
    AWP,
    M4A1,
};

struct HeavyGunProperties{
    std::string name;
    int cost;
    int damage;
    int price;
    bool isForTerrorist;
    bool isForCounterTerrorist;
    HeavyGunType type;
};

HeavyGunProperties* getHeavyGunPropertyByName(const std::string &name);

const HeavyGunProperties heavyGunPropertiesList[4] = {
        {"AK", 2700, 31, 100, true, false,      HeavyGunType::AK},
        {"AWP", 4300, 110, 50, true, true,     HeavyGunType::AWP},
        {"M4A1", 2700, 29, 100, false, true, HeavyGunType::M4A1},

};





#endif //COUNTER_HEAVYGUNTYPE_H

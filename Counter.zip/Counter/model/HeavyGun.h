//
// Created by DavoudAbadi on 12/1/2023.
//

#ifndef COUNTER_HEAVYGUN_H
#define COUNTER_HEAVYGUN_H


#include <string>
#include "HeavyGunType.h"

class HeavyGun{
private:
    HeavyGunProperties properties;
public:
    HeavyGun(const HeavyGunProperties& properties1);

    const HeavyGunProperties &getProperties() const;
};


#endif //COUNTER_HEAVYGUN_H

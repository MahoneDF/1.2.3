#include "vector"

//
// Created by DavoudAbadi on 11/28/2023.
//

#ifndef COUNTER_GAME_H
#define COUNTER_GAME_H


#include "User.h"

class Game {
public:
    Game(int& round);
    void addUser(User& user);
    User getUserByName(const std::string& username);
    int getNumberOfTerrorist();
    int getNumberOfCounterTerrorist();
    void decRound();

    std::vector<User> &getAllUsers();

    int getRound() const;
    void decNumberOfCommands();
    void setNumberOfCommands(int numberOfCommands);

    int getNumberOfCommands() const;

    int getPassedRound() const;
    void incPassedRound();

private:
    int round;
    int numberOfCommands;
    int passedRound;
    std::vector<User> allUsers;



};


#endif //COUNTER_GAME_H

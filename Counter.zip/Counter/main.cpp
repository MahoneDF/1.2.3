#include <iostream>
#include <regex>
#include <string>
#include "view/Start.h"
#include "controller/Controller.h"

int main() {
    int round;
    std::cin >> round;
    Game game(round);
    Controller::setGame(&game);
    Start::run(&game);
    return 0;
}
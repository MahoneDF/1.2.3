//
// Created by DavoudAbadi on 12/15/2023.
//


#include <string>
#include <iostream>
#include <vector>
#include <regex>

enum class HandgunType{
    REVOLVER,
    GLOCK_18,
    DESERT_EAGLE,
    UPS_S
};

struct HandgunProperties{
    std::string name;
    int cost;
    int damage;
    int price;
    bool isForTerrorist;
    bool isForCounterTerrorist;
    HandgunType type;
};

HandgunProperties* getHandgunPropertyByName(const std::string &name);

const HandgunProperties handgunPropertiesList[4] = {
        {"Revolver", 600, 51, 150, true, false,  HandgunType::REVOLVER},
        {"Glock-18", 300, 11, 200, true, false,      HandgunType::GLOCK_18},
        {"Desert-Eagle", 600, 53, 175, false, true, HandgunType::DESERT_EAGLE},
        {"UPS-S", 300, 13, 225, false, true,        HandgunType::UPS_S}
};


enum class HeavyGunType{
    AK,
    AWP,
    M4A1,
};

struct HeavyGunProperties{
    std::string name;
    int cost;
    int damage;
    int price;
    bool isForTerrorist;
    bool isForCounterTerrorist;
    HeavyGunType type;
};

HeavyGunProperties* getHeavyGunPropertyByName(const std::string &name);

const HeavyGunProperties heavyGunPropertiesList[4] = {
        {"AK", 2700, 31, 100, true, false,      HeavyGunType::AK},
        {"AWP", 4300, 110, 50, true, true,     HeavyGunType::AWP},
        {"M4A1", 2700, 29, 100, false, true, HeavyGunType::M4A1},

};




enum class Massage {
    USERNAME_EXISTS,
    TEAM_IS_FULL,
    SUCCESS_ADD,

    INVALID_USERNAME,
    GET_MONEY,
    GET_HEALTH,

    DEAD_ATTACKER,
    DEAD_ATTACKED,
    GUN_DOES_NOT_EXISTS,
    FRIENDLY_FIRE,
    NICE_SHOT,

    USER_IS_DEAD,
    OUT_OF_TIME,
    INVALID_CATEGORY_GUN,
    HANDGUN_EXISTS,
    HEAVY_GUN_EXISTS,
    NO_ENOUGH_MONEY,
    SUCCESS_BUY,

    TERRORIST_WIN,
    COUNTER_TERRORIST_WIN,
    FIRST_ROUND,
};




class Handgun{
private:
    HandgunProperties properties;
public:
    Handgun(const HandgunProperties& properties1);

    const HandgunProperties &getProperties() const;


};


class HeavyGun{
private:
    HeavyGunProperties properties;
public:
    HeavyGun(const HeavyGunProperties& properties1);

    const HeavyGunProperties &getProperties() const;
};
class User {
public:
    User(const std::string& _username, const std::string& _team);
    HeavyGun getHeavyGun();
    Handgun getHandgun();
    int getHealth();
    const std::string& getUsername() const;
    bool haveHeavyGun() const;
    bool haveHandgun() const;
    int getMoney() const;
    bool isTerrorist() const;


    void setHaveHeavyGun(bool haveHeavyGun);

    void setHaveHandgun(bool haveHandgun);

    void setMoney(int money);

    void setHeavyGun(const HeavyGun &heavyGun);

    void setHandgun(const Handgun &handgun);

    void setHealth(int health);
    void incNumberOfKill();

    void incNumberOfDeath();

    int getNumberOfKill() const;

    int getNumberOfDeath() const;

private:
    std::string username;
    bool is_terrorist;
    HeavyGun heavyGun;
    Handgun handgun;
    int health;
    int money;
    bool have_heavyGun;
    bool have_handgun;
    int numberOfKill;
    int numberOfDeath;
};
class Game {
public:
    Game(int& round);
    void addUser(User& user);
    User getUserByName(const std::string& username);
    int getNumberOfTerrorist();
    int getNumberOfCounterTerrorist();
    void decRound();

    std::vector<User> &getAllUsers();

    int getRound() const;
    void decNumberOfCommands();
    void setNumberOfCommands(int numberOfCommands);

    int getNumberOfCommands() const;

    int getPassedRound() const;
    void incPassedRound();

private:
    int round;
    int numberOfCommands;
    int passedRound;
    std::vector<User> allUsers;



};


enum class CommandRegex {
    ROUND,
    ADD_USER,
    GET_MONEY,
    GET_HEALTH,
    TAP,
    BUY,
    SCOREBOARD
};
struct Command {
    std::string regex;
    CommandRegex command;
};
static const Command regexPatterns[7] = {
        {"^ROUND (\\S+)$", CommandRegex::ROUND},
        {"^ADD-USER (\\S+) (Counter-Terrorist|Terrorist) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                                        CommandRegex::ADD_USER},
        {"^GET-MONEY (\\S+) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                                             CommandRegex::GET_MONEY},
        {"^GET-HEALTH (\\S+) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                                             CommandRegex::GET_HEALTH},
        {"^TAP (\\S+) (\\S+) (heavy|pistol|knife) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                                             CommandRegex::TAP},
        {"^BUY (\\S+) (\\S+) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                     CommandRegex::BUY},
        {"SCORE-BOARD ([0-9]{2}):([0-9]{2}):([0-9]{3})", CommandRegex::SCOREBOARD}
};

static std::smatch getMatcher(const std::string& input, CommandRegex mainRegex);

class Start {
private:
    static Game* game;
    static void sortForScoreboard(std::vector<User>& users);
public:


     static void setGame(Game* game);

     static void run(Game* game);
     static void checkAddUser(const std::smatch& matcher);
     static void checkGetMoney(const std::smatch& matcher);
     static void checkGetHealth(const std::smatch& matcher);
     static void checkTap(const std::smatch& matcher);
     static void checkBuy(const std::smatch& matcher);
     static void checkNewRound();
     static void scoreboard();


     static void startNewRound(const std::smatch& matcher);
};



class Controller {
private:
    static Game* game;
public:
    static void setGame(Game* game);

    static Massage addUser(const std::string& username, const std::string& team, const int& minutes, const int& seconds, const int& miliseconds, Game* game1);
    static Massage tap(std::string& attackerName, std::string& attackedName, std::string& gunName, Game* game1);



    static Massage getMoney(const std::string &username, const int &minutes, const int &seconds, const int &miliseconds, Game* game1);

    static Massage getHealth(const std::string &username, const int &minutes, const int &seconds, const int &miliseconds, Game* game1);

    static Massage buy(std::string &username, std::string &gunName, const int &minutes, const int &seconds, const int &miliseconds, Game* game1);



    static bool checkTime(const int &minutes1, const int &seconds1, const int &miliseconds1, const int &minutes2,
                          const int &seconds2,
                          const int &miliseconds2);

    static Massage newRound(Game* game1);


    static User &getUserByName(const std::string &username);
};

Game* Controller::game = nullptr;

Massage Controller::addUser(const std::string& username, const std::string& team, const int& minutes, const int& seconds, const int& miliseconds, Game* game1) {
    game = game1;
    if(!game->getUserByName(username).getUsername().empty()){
        return Massage::USERNAME_EXISTS;
    } else if((team == "Terrorist" && game->getNumberOfTerrorist() >= 10) || (team == "Counter-Terrorist" && game->getNumberOfCounterTerrorist() >= 10)){
        return Massage::TEAM_IS_FULL;
    }else{
        User user(username, team);
        game->addUser(user);
        if(checkTime(minutes, seconds, miliseconds, 0, 3, 0)){
            for(auto & user1 : game->getAllUsers()){
                if(user1.getUsername() == username) {
                    user1.setHealth(0);
                }
            }
        }

        return Massage::SUCCESS_ADD;
    }
}


Massage Controller::getMoney(const std::string& username, const int& minutes, const int& seconds, const int& miliseconds, Game* game1){
    game = game1;
    if(game->getUserByName(username).getUsername().empty()){
        return Massage::INVALID_USERNAME;
    }else{
        return Massage::GET_MONEY;
    }
}

Massage Controller::getHealth(const std::string& username, const int& minutes, const int& seconds, const int& miliseconds, Game* game1){
    game = game1;
    if(game->getUserByName(username).getUsername().empty()){
        return Massage::INVALID_USERNAME;
    }else{
        return Massage::GET_HEALTH;
    }
}

Massage Controller::tap(std::string& attackerName, std::string& attackedName, std::string& gunName, Game* game1) {
    game = game1;
    if(game->getUserByName(attackerName).getUsername().empty() || game->getUserByName(attackedName).getUsername().empty()){
        return Massage::INVALID_USERNAME;
    }else if(game->getUserByName(attackerName).getHealth() == 0){
        return Massage::DEAD_ATTACKER;
    }else if(game->getUserByName(attackedName).getHealth() == 0){
        return Massage::DEAD_ATTACKED;
    }else if((gunName == "heavy" && !game->getUserByName(attackerName).haveHeavyGun()) || (gunName == "pistol" && !game->getUserByName(attackerName).haveHandgun())){
        return Massage::GUN_DOES_NOT_EXISTS;
    } else if (game->getUserByName(attackerName).isTerrorist() == game->getUserByName(attackedName).isTerrorist()){
        return Massage::FRIENDLY_FIRE;
    } else{
        int damage;
        int price;
        if(gunName == "heavy"){
            damage = game->getUserByName(attackerName).getHeavyGun().getProperties().damage;
            price = game->getUserByName(attackerName).getHeavyGun().getProperties().price;

        }else if(gunName == "pistol"){
            damage = game->getUserByName(attackerName).getHandgun().getProperties().damage;
            price = game->getUserByName(attackerName).getHandgun().getProperties().price;
        }else{
            damage = 43;
            price = 500;
        }
        bool isKilled = false;
        for(auto & user : game->getAllUsers()){
            if(user.getUsername() == attackedName){
                user.setHealth(std::max(user.getHealth() - damage, 0));
                if(user.getHealth() == 0){
                    isKilled = true;
                    user.incNumberOfDeath();
                }
            }
        }
        if(isKilled){
            for(auto & user : game->getAllUsers()){
                if(user.getUsername() == attackerName){
                    user.incNumberOfKill();
                    user.setMoney(std::min(game->getUserByName(attackerName).getMoney() + price, 10000));
                }
            }
        }

        return Massage::NICE_SHOT;
    }
}

Massage Controller::buy(std::string& username, std::string& gunName, const int& minutes, const int& seconds, const int& miliseconds, Game* game1) {
    game = game1;
    if(game->getUserByName(username).getUsername().empty()){
        return Massage::INVALID_USERNAME;
    } else if(game->getUserByName(username).getHealth() == 0){
        return Massage::USER_IS_DEAD;
    } else if (checkTime(minutes, seconds, miliseconds, 0, 45, 0)){
        return Massage::OUT_OF_TIME;
    } else if(getHandgunPropertyByName(gunName) != nullptr){
        if(game->getUserByName(username).isTerrorist() && !getHandgunPropertyByName(gunName)->isForTerrorist){
            return Massage::INVALID_CATEGORY_GUN;
        } else if(!game->getUserByName(username).isTerrorist() && !getHandgunPropertyByName(gunName)->isForCounterTerrorist){
            return Massage::INVALID_CATEGORY_GUN;
        }else if(game->getUserByName(username).haveHandgun()){
            return Massage::HANDGUN_EXISTS;
        }
        else if(game->getUserByName(username).getMoney() < getHandgunPropertyByName(gunName)->cost){
            return Massage::NO_ENOUGH_MONEY;
        }else{
            for(auto & user : game->getAllUsers()){
                if(user.getUsername() == username){
                    Handgun handgun(*getHandgunPropertyByName(gunName));
                    user.setHandgun(handgun);
                    user.setMoney(user.getMoney() - handgun.getProperties().cost);
                    return Massage::SUCCESS_BUY;
                }
            }

        }
    }else if(getHeavyGunPropertyByName(gunName) != nullptr){
        if(game->getUserByName(username).isTerrorist() && !getHeavyGunPropertyByName(gunName)->isForTerrorist){
            return Massage::INVALID_CATEGORY_GUN;
        } else if(!game->getUserByName(username).isTerrorist() && !getHeavyGunPropertyByName(gunName)->isForCounterTerrorist){
            return Massage::INVALID_CATEGORY_GUN;
        }else if(game->getUserByName(username).haveHeavyGun()){
            return Massage::HEAVY_GUN_EXISTS;
        }else if(game->getUserByName(username).getMoney() < getHeavyGunPropertyByName(gunName)->cost){
            return Massage::NO_ENOUGH_MONEY;
        }else{
            for(auto & user : game->getAllUsers()){
                if(user.getUsername() == username){
                    HeavyGun heavyGun(*getHeavyGunPropertyByName(gunName));
                    user.setHeavyGun(heavyGun);
                    user.setMoney(user.getMoney() - heavyGun.getProperties().cost);
                    return Massage::SUCCESS_BUY;
                }
            }

        }
    }
}

Massage Controller::newRound(Game* game1){
    game = game1;
    bool isCounterTerroristWin = true;
    int counterTerroristPrice = 2700;
    int terroristPrice = 2400;
    int numberOfTerroristAlive = 0;
    int numberOfCounterTerroristAlive = 0;
    for(auto& user : game->getAllUsers()){
        if(user.getHealth() > 0){
            if(user.isTerrorist()){
                numberOfTerroristAlive++;
            } else{
                numberOfCounterTerroristAlive++;
            }
        } else{
            user.setHaveHeavyGun(false);
            user.setHaveHandgun(false);
        }
    }
    if(numberOfCounterTerroristAlive == 0 && numberOfTerroristAlive > 0){
        isCounterTerroristWin = false;
        counterTerroristPrice = 2400;
        terroristPrice = 2700;
    }
    for(auto& user : game->getAllUsers()){
        user.setHealth(100);
        if(user.isTerrorist()){
            user.setMoney(std::min(user.getMoney() + terroristPrice,  10000));
        } else{
            user.setMoney(std::min(user.getMoney() + counterTerroristPrice,  10000));
        }

    }
    game->decRound();
    if(isCounterTerroristWin){
        return Massage::COUNTER_TERRORIST_WIN;
    }
    return Massage::TERRORIST_WIN;


}

void Controller::setGame(Game* game1) {
    game = game1;
}


bool Controller::checkTime(const int& minutes1, const int& seconds1, const int& miliseconds1, const int& minutes2, const int& seconds2, const int& miliseconds2) {
    if(minutes1 > minutes2){
        return true;
    }
    if (minutes1 == minutes2 && seconds1 > seconds2){
        return true;
    }
    if (minutes1 == minutes2 && seconds1 == seconds2 && miliseconds1 >= miliseconds2){
        return true;
    }
    return false;
}





void Game::addUser(User &user) {
    allUsers.push_back(user);
}

User Game::getUserByName(const std::string& username) {
    for(const auto & allUser : allUsers){
        if(allUser.getUsername() == username){
            return allUser;
        }
    }
    return User("", "Terrorist");
}

Game::Game(int &round1) {
    round = round1;
    passedRound = 0;
}

int Game::getNumberOfTerrorist() {
    int t = 0;
    for(const auto & user : allUsers){
        if(user.isTerrorist()){
            t++;
        }
    }
    return t;
}

int Game::getNumberOfCounterTerrorist() {
    int t = 0;
    for(const auto & user : allUsers){
        if(!user.isTerrorist()){
            t++;
        }
    }
    return t;
}
void Game::incPassedRound(){
    passedRound++;
}
void Game::decRound() {
    round--;
}

int Game::getRound() const {
    return round;
}

std::vector<User> &Game::getAllUsers() {
    return allUsers;
}

int Game::getPassedRound() const {
    return passedRound;
}

int Game::getNumberOfCommands() const {
    return numberOfCommands;
}

void Game::setNumberOfCommands(int numberOfCommands) {
    Game::numberOfCommands = numberOfCommands;
}

void Game::decNumberOfCommands() {
    numberOfCommands--;
}

//handgun method

Handgun::Handgun(const HandgunProperties& properties1) {
    properties = properties1;
}

const HandgunProperties &Handgun::getProperties() const {
    return properties;
}


HandgunProperties* getHandgunPropertyByName(const std::string &name) {
    for (int i = 0; i < 4; i++) {
        if (handgunPropertiesList[i].name == name) {
            return const_cast<HandgunProperties *>(&(handgunPropertiesList[i]));
        }
    }
    return nullptr;

}


HeavyGun::HeavyGun(const HeavyGunProperties& properties1) {
    properties = properties1;
}

const HeavyGunProperties &HeavyGun::getProperties() const {
    return properties;
}


HeavyGunProperties* getHeavyGunPropertyByName(const std::string &name) {
    for (int i = 0; i < 4; i++) {
        if (heavyGunPropertiesList[i].name == name) {
            return const_cast<HeavyGunProperties *>(&heavyGunPropertiesList[i]);
        }
    }
    return nullptr;
}



int User::getHealth(){
    return health;
}

User::User(const std::string& _username, const std::string& _team): handgun(HandgunProperties()), heavyGun(HeavyGunProperties()){
    username = _username;
    if(_team == "Terrorist"){
        is_terrorist = true;
    } else if (_team == "Counter-Terrorist"){
        is_terrorist = false;
    }
    have_handgun = false;
    have_heavyGun = false;
    health = 100;
    money = 1000;
    numberOfDeath = 0;
    numberOfKill = 0;
}

HeavyGun User::getHeavyGun() {
    return heavyGun;
}

Handgun User::getHandgun() {
    return handgun;
}

const std::string &User::getUsername() const {
    return username;
}

int User::getMoney() const {
    return money;
}

bool User::isTerrorist() const {
    return is_terrorist;
}

bool User::haveHeavyGun() const {
    return have_heavyGun;
}

bool User::haveHandgun() const {
    return have_handgun;
}

void User::setHeavyGun(const HeavyGun &heavyGun) {
    User::heavyGun = heavyGun;
    have_heavyGun = true;
}

void User::setHandgun(const Handgun &handgun) {
    User::handgun = handgun;
    have_handgun = true;
}

void User::setHealth(int health) {
    User::health = health;
}

void User::setMoney(int money) {
    User::money = money;
}

void User::setHaveHeavyGun(bool haveHeavyGun) {
    have_heavyGun = haveHeavyGun;
}

void User::setHaveHandgun(bool haveHandgun) {
    have_handgun = haveHandgun;
}

void User::incNumberOfKill(){
    numberOfKill++;
}

void User::incNumberOfDeath(){
    numberOfDeath++;
}

int User::getNumberOfKill() const {
    return numberOfKill;
}

int User::getNumberOfDeath() const {
    return numberOfDeath;
}



//Start methods........................................................................................

Game* Start::game = nullptr;

std::smatch getMatcher(const std::string &input, CommandRegex mainRegex) {

    std::regex regEx(regexPatterns[static_cast<int>(mainRegex)].regex);
    std::smatch matches;
    if (std::regex_match(input, matches, regEx)) {
        return matches;
    }
    return std::smatch();
}

void Start::run(Game* game1) {
    game = game1;
    Controller::setGame(game1);
    while (true) {
        std::string input;
        std::getline(std::cin, input);
        game->decNumberOfCommands();
        std::smatch matcher;
        if (!(matcher = getMatcher(input, CommandRegex::ADD_USER)).empty()) {
            checkAddUser(matcher);
        } else if (!(matcher = getMatcher(input, CommandRegex::GET_MONEY)).empty()) {
            checkGetMoney(matcher);
        } else if (!(matcher = getMatcher(input, CommandRegex::GET_HEALTH)).empty()) {
            checkGetHealth(matcher);
        } else if (!(matcher = getMatcher(input, CommandRegex::TAP)).empty()) {
            checkTap(matcher);
        } else if (!(matcher = getMatcher(input, CommandRegex::BUY)).empty()) {
            checkBuy(matcher);
        } else if (!(getMatcher(input, CommandRegex::SCOREBOARD)).empty()) {
            scoreboard();
        }
        if(game->getNumberOfCommands() == 0){
            checkNewRound();
            if(game->getRound() == 0){
                break;
            }

        }

        if(!(matcher = getMatcher(input, CommandRegex::ROUND)).empty()){
            startNewRound(matcher);
        }

    }

}

void Start::checkAddUser(const std::smatch& matcher) {
    std::string username = matcher.str(1);
    std::string team = matcher.str(2);
    int minutes = std::stoi(matcher.str(3));
    int seconds = std::stoi(matcher.str(4));
    int miliseconds = std::stoi(matcher.str(5));
    Massage massage = Controller::addUser(username, team, minutes, seconds, miliseconds, game);
    switch (massage) {
        case Massage::USERNAME_EXISTS:
            std::cout << "you are already in this game" << std::endl;
            break;
        case Massage::TEAM_IS_FULL:
            std::cout << "this team is full" << std::endl;
            break;
        case Massage::SUCCESS_ADD:
            std::cout << "this user added to " << team << std::endl;
            break;
        default:
            break;
    }

}

void Start::checkGetMoney(const std::smatch& matcher) {
    std::string username = matcher.str(1);
    int minutes = std::stoi(matcher.str(2));
    int seconds = std::stoi(matcher.str(3));
    int miliseconds = std::stoi(matcher.str(4));
    Massage massage = Controller::getMoney(username, minutes, seconds, miliseconds, game);
    switch (massage) {
        case Massage::INVALID_USERNAME:
            std::cout << "invalid username" << std::endl;
            break;
        case Massage::GET_MONEY:
            std::cout << game->getUserByName(username).getMoney() << std::endl;
            break;
        default:
            break;
    }
}

void Start::checkGetHealth(const std::smatch& matcher) {
    std::string username = matcher.str(1);
    int minutes = std::stoi(matcher.str(2));
    int seconds = std::stoi(matcher.str(3));
    int miliseconds = std::stoi(matcher.str(4));
    Massage massage = Controller::getHealth(username, minutes, seconds, miliseconds, game);
    switch (massage) {
        case Massage::INVALID_USERNAME:
            std::cout << "invalid username" << std::endl;
            break;
        case Massage::GET_HEALTH:
            std::cout << game->getUserByName(username).getHealth() << std::endl;
            break;
        default:
            break;
    }
}

void Start::checkTap(const std::smatch& matcher) {
    std::string attackerName = matcher.str(1);
    std::string attackedName = matcher.str(2);
    std::string gunName = matcher.str(3);
    int minutes = std::stoi(matcher.str(4));
    int seconds = std::stoi(matcher.str(5));
    int miliseconds = std::stoi(matcher.str(6));
    Massage massage = Controller::tap(attackerName, attackedName, gunName, game);
    switch (massage) {
        case Massage::INVALID_USERNAME:
            std::cout << "invalid username" << std::endl;
            break;
        case Massage::DEAD_ATTACKER:
            std::cout << "attacker is dead" << std::endl;
            break;
        case Massage::DEAD_ATTACKED:
            std::cout << "attacked is dead" << std::endl;
            break;
        case Massage::GUN_DOES_NOT_EXISTS:
            std::cout << "no such gun" << std::endl;
            break;
        case Massage::FRIENDLY_FIRE:
            std::cout << "friendly fire" << std::endl;
            break;
        case Massage::NICE_SHOT:
            std::cout << "nice shot" << std::endl;
            break;
        default:
            break;
    }

}

void Start::checkBuy(const std::smatch& matcher) {
    std::string username = matcher.str(1);
    std::string gunName = matcher.str(2);
    int minutes = std::stoi(matcher.str(3));
    int seconds = std::stoi(matcher.str(4));
    int miliseconds = std::stoi(matcher.str(5));
    Massage massage = Controller::buy(username, gunName, minutes, seconds, miliseconds, game);
    switch (massage) {
        case Massage::INVALID_USERNAME:
            std::cout << "invalid username" << std::endl;
            break;
        case Massage::USER_IS_DEAD:
            std::cout << "deads can not buy" << std::endl;
            break;
        case Massage::OUT_OF_TIME:
            std::cout << "you are out of time" << std::endl;
            break;
        case Massage::INVALID_CATEGORY_GUN:
            std::cout << "invalid category gun" << std::endl;
            break;
        case Massage::HEAVY_GUN_EXISTS:
            std::cout << "you have a heavy" << std::endl;
            break;
        case Massage::HANDGUN_EXISTS:
            std::cout << "you have a pistol" << std::endl;
            break;
        case Massage::NO_ENOUGH_MONEY:
            std::cout << "no enough money" << std::endl;
            break;
        case Massage::SUCCESS_BUY:
            std::cout << "I hope you can use it" << std::endl;
            break;
    }
}

void Start::checkNewRound(){
    Massage massage = Controller::newRound(game);
    switch (massage) {
        case Massage::TERRORIST_WIN:
            std::cout << "Terrorist won" << std::endl;
            break;
        case Massage::COUNTER_TERRORIST_WIN:
            std::cout << "Counter-Terrorist won" << std::endl;
            break;
        default:
            break;
    }
}

void Start::setGame(Game* game) {
    Start::game = game;
}

void Start::scoreboard() {
    std::cout << "Counter-Terrorist-Players:" << std::endl;
    std::vector<User> terrorists;
    std::vector<User> counterTerrorists;
    for(auto& user : game->getAllUsers()){
        if(user.isTerrorist()){
            terrorists.push_back(user);
        }else{
            counterTerrorists.push_back(user);
        }
    }
    sortForScoreboard(counterTerrorists);
    int i = 1;
    for(auto& user : counterTerrorists){
        std::cout << i << " " << user.getUsername() << " " << user.getNumberOfKill() << " " << user.getNumberOfDeath() << std::endl;
        i++;
    }
    std::cout << "Terrorist-Players:" << std::endl;
    i = 1;
    sortForScoreboard(terrorists);
    for(auto& user : terrorists){
        std::cout << i << " " << user.getUsername() << " " << user.getNumberOfKill() << " " << user.getNumberOfDeath() << std::endl;
        i++;
    }
}

void Start::sortForScoreboard(std::vector<User> &users) {
    for(int i = 0; i < users.size(); i++){
        for(int j = 0; j < users.size()-1; j++){
            if((users[j].getNumberOfKill() < users[j+1].getNumberOfKill()) || (users[j].getNumberOfKill() == users[j+1].getNumberOfKill() && users[j].getNumberOfDeath() > users[j+1].getNumberOfDeath())){
                User user = users[j];
                users[j] = users[j+1];
                users[j+1] = user;
            }
        }
    }
}

void Start::startNewRound(const std::smatch& matcher){
    int commands = std::stoi(matcher.str(1));
    game->setNumberOfCommands(commands);
}








int main() {
    int round;
    std::cin >> round;
    Game game(round);
    Controller::setGame(&game);
    Start::run(&game);
    return 0;
}

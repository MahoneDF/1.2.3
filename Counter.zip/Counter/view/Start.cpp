//
// Created by DavoudAbadi on 12/4/2023.
//

#include "Start.h"
#include "../controller/Controller.h"

Game* Start::game = nullptr;

std::smatch getMatcher(const std::string &input, CommandRegex mainRegex) {

    std::regex regEx(regexPatterns[static_cast<int>(mainRegex)].regex);
    std::smatch matches;
    if (std::regex_match(input, matches, regEx)) {
        return matches;
    }
    return std::smatch();
}

void Start::run(Game* game1) {
    game = game1;
    Controller::setGame(game1);
    while (true) {
        std::string input;
        std::getline(std::cin, input);
        game->decNumberOfCommands();
        std::smatch matcher;
        if (!(matcher = getMatcher(input, CommandRegex::ADD_USER)).empty()) {
            checkAddUser(matcher);
        } else if (!(matcher = getMatcher(input, CommandRegex::GET_MONEY)).empty()) {
            checkGetMoney(matcher);
        } else if (!(matcher = getMatcher(input, CommandRegex::GET_HEALTH)).empty()) {
            checkGetHealth(matcher);
        } else if (!(matcher = getMatcher(input, CommandRegex::TAP)).empty()) {
            checkTap(matcher);
        } else if (!(matcher = getMatcher(input, CommandRegex::BUY)).empty()) {
            checkBuy(matcher);
        } else if (!(getMatcher(input, CommandRegex::SCOREBOARD)).empty()) {
            scoreboard();
        }
        if(game->getNumberOfCommands() == 0){
            checkNewRound();
            if(game->getRound() == 0){
                break;
            }

        }

        if(!(matcher = getMatcher(input, CommandRegex::ROUND)).empty()){
            startNewRound(matcher);
            if(game->getNumberOfCommands() == 0){
                checkNewRound();
                if(game->getRound() == 0){
                    break;
                }

            }
        }



    }

}

void Start::checkAddUser(const std::smatch& matcher) {
    std::string username = matcher.str(1);
    std::string team = matcher.str(2);
    int minutes = std::stoi(matcher.str(3));
    int seconds = std::stoi(matcher.str(4));
    int miliseconds = std::stoi(matcher.str(5));
    Massage massage = Controller::addUser(username, team, minutes, seconds, miliseconds, game);
    switch (massage) {
        case Massage::USERNAME_EXISTS:
            std::cout << "you are already in this game" << std::endl;
            break;
        case Massage::TEAM_IS_FULL:
            std::cout << "this team is full" << std::endl;
            break;
        case Massage::SUCCESS_ADD:
            std::cout << "this user added to " << team << std::endl;
            break;
        default:
            break;
    }

}

void Start::checkGetMoney(const std::smatch& matcher) {
    std::string username = matcher.str(1);
    int minutes = std::stoi(matcher.str(2));
    int seconds = std::stoi(matcher.str(3));
    int miliseconds = std::stoi(matcher.str(4));
    Massage massage = Controller::getMoney(username, minutes, seconds, miliseconds, game);
    switch (massage) {
        case Massage::INVALID_USERNAME:
            std::cout << "invalid username" << std::endl;
            break;
        case Massage::GET_MONEY:
            std::cout << game->getUserByName(username).getMoney() << std::endl;
            break;
        default:
            break;
    }
}

void Start::checkGetHealth(const std::smatch& matcher) {
    std::string username = matcher.str(1);
    int minutes = std::stoi(matcher.str(2));
    int seconds = std::stoi(matcher.str(3));
    int miliseconds = std::stoi(matcher.str(4));
    Massage massage = Controller::getHealth(username, minutes, seconds, miliseconds, game);
    switch (massage) {
        case Massage::INVALID_USERNAME:
            std::cout << "invalid username" << std::endl;
            break;
        case Massage::GET_HEALTH:
            std::cout << game->getUserByName(username).getHealth() << std::endl;
            break;
        default:
            break;
    }
}

void Start::checkTap(const std::smatch& matcher) {
    std::string attackerName = matcher.str(1);
    std::string attackedName = matcher.str(2);
    std::string gunName = matcher.str(3);
    int minutes = std::stoi(matcher.str(4));
    int seconds = std::stoi(matcher.str(5));
    int miliseconds = std::stoi(matcher.str(6));
    Massage massage = Controller::tap(attackerName, attackedName, gunName, game);
    switch (massage) {
        case Massage::INVALID_USERNAME:
            std::cout << "invalid username" << std::endl;
            break;
        case Massage::DEAD_ATTACKER:
            std::cout << "attacker is dead" << std::endl;
            break;
        case Massage::DEAD_ATTACKED:
            std::cout << "attacked is dead" << std::endl;
            break;
        case Massage::GUN_DOES_NOT_EXISTS:
            std::cout << "no such gun" << std::endl;
            break;
        case Massage::FRIENDLY_FIRE:
            std::cout << "friendly fire" << std::endl;
            break;
        case Massage::NICE_SHOT:
            std::cout << "nice shot" << std::endl;
            break;
        default:
            break;
    }

}

void Start::checkBuy(const std::smatch& matcher) {
    std::string username = matcher.str(1);
    std::string gunName = matcher.str(2);
    int minutes = std::stoi(matcher.str(3));
    int seconds = std::stoi(matcher.str(4));
    int miliseconds = std::stoi(matcher.str(5));
    Massage massage = Controller::buy(username, gunName, minutes, seconds, miliseconds, game);
    switch (massage) {
        case Massage::INVALID_USERNAME:
            std::cout << "invalid username" << std::endl;
            break;
        case Massage::USER_IS_DEAD:
            std::cout << "deads can not buy" << std::endl;
            break;
        case Massage::OUT_OF_TIME:
            std::cout << "you are out of time" << std::endl;
            break;
        case Massage::INVALID_CATEGORY_GUN:
            std::cout << "invalid category gun" << std::endl;
            break;
        case Massage::HEAVY_GUN_EXISTS:
            std::cout << "you have a heavy" << std::endl;
            break;
        case Massage::HANDGUN_EXISTS:
            std::cout << "you have a pistol" << std::endl;
            break;
        case Massage::NO_ENOUGH_MONEY:
            std::cout << "no enough money" << std::endl;
            break;
        case Massage::SUCCESS_BUY:
            std::cout << "I hope you can use it" << std::endl;
            break;
    }
}

void Start::checkNewRound(){
    Massage massage = Controller::newRound(game);
    switch (massage) {
        case Massage::TERRORIST_WIN:
            std::cout << "Terrorist won" << std::endl;
            break;
        case Massage::COUNTER_TERRORIST_WIN:
            std::cout << "Counter-Terrorist won" << std::endl;
            break;
        default:
            break;
    }
}

void Start::setGame(Game* game) {
    Start::game = game;
}

void Start::scoreboard() {
    std::cout << "Counter-Terrorist-Players:" << std::endl;
    std::vector<User> terrorists;
    std::vector<User> counterTerrorists;
    for(auto& user : game->getAllUsers()){
        if(user.isTerrorist()){
            terrorists.push_back(user);
        }else{
            counterTerrorists.push_back(user);
        }
    }
    sortForScoreboard(counterTerrorists);
    int i = 1;
    for(auto& user : counterTerrorists){
        std::cout << i << " " << user.getUsername() << " " << user.getNumberOfKill() << " " << user.getNumberOfDeath() << std::endl;
        i++;
    }
    std::cout << "Terrorist-Players:" << std::endl;
    i = 1;
    sortForScoreboard(terrorists);
    for(auto& user : terrorists){
        std::cout << i << " " << user.getUsername() << " " << user.getNumberOfKill() << " " << user.getNumberOfDeath() << std::endl;
        i++;
    }
}

void Start::sortForScoreboard(std::vector<User> &users) {
    for(int i = 0; i < users.size(); i++){
        for(int j = 0; j < users.size()-1; j++){
            if((users[j].getNumberOfKill() < users[j+1].getNumberOfKill()) || (users[j].getNumberOfKill() == users[j+1].getNumberOfKill() && users[j].getNumberOfDeath() > users[j+1].getNumberOfDeath())){
                User user = users[j];
                users[j] = users[j+1];
                users[j+1] = user;
            }
        }
    }
}

void Start::startNewRound(const std::smatch& matcher){
    int commands = std::stoi(matcher.str(1));
    game->setNumberOfCommands(commands);
}




//
// Created by DavoudAbadi on 12/4/2023.
//

#ifndef COUNTER_COMMANDS_H
#define COUNTER_START_H


#include "iostream"
#include <regex>
#include <string>
#include "../model/Game.h"

enum class CommandRegex {
    ROUND,
    ADD_USER,
    GET_MONEY,
    GET_HEALTH,
    TAP,
    BUY,
    SCOREBOARD
};
struct Command {
    std::string regex;
    CommandRegex command;
};
static const Command regexPatterns[7] = {
        {"^ROUND (\\S+)$", CommandRegex::ROUND},
        {"^ADD-USER (\\S+) (Counter-Terrorist|Terrorist) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                                        CommandRegex::ADD_USER},
        {"^GET-MONEY (\\S+) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                                             CommandRegex::GET_MONEY},
        {"^GET-HEALTH (\\S+) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                                             CommandRegex::GET_HEALTH},
        {"^TAP (\\S+) (\\S+) (heavy|pistol|knife) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                                             CommandRegex::TAP},
        {"^BUY (\\S+) (\\S+) ([0-9]{2}):([0-9]{2}):([0-9]{3})$",                     CommandRegex::BUY},
        {"SCORE-BOARD ([0-9]{2}):([0-9]{2}):([0-9]{3})", CommandRegex::SCOREBOARD}
};

static std::smatch getMatcher(const std::string& input, CommandRegex mainRegex);

class Start {
private:
    static Game* game;
    static void sortForScoreboard(std::vector<User>& users);
public:


    static void setGame(Game* game);

    static void run(Game* game);
    static void checkAddUser(const std::smatch& matcher);
    static void checkGetMoney(const std::smatch& matcher);
    static void checkGetHealth(const std::smatch& matcher);
    static void checkTap(const std::smatch& matcher);
    static void checkBuy(const std::smatch& matcher);
    static void checkNewRound();
    static void scoreboard();


    static void startNewRound(const std::smatch& matcher);
};




#endif //COUNTER_COMMANDS_H
